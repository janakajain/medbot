


keys = ["name","nickname","sex","age","phone","address","city","zipcode","medication",""]